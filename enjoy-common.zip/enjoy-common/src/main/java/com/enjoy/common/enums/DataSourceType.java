package com.enjoy.common.enums;

/**
 * 数据源
 *
 * @author enjoy
 */
public enum DataSourceType
{
    /**
     * 主库
     */
    MASTER,

    /**
     * 从库
     */
    SLAVE
}
