package com.enjoy.common.core.domain;

import java.io.Serializable;

/**
 * 脑图树节点 实体
 *
 * @author outian
 * @date 2021/11/29
 */
public class MinderTreeNode implements Serializable {
    private static final long serialVersionUID = -8136388568849831017L;

    /**
     * ID
     */
    private Long id;

    /**
     * 业务ID
     */
    private Long extraId;

    /**
     * 节点类型
     */
    private Integer nodeType;

    /**
     * 节点关系
     */
    private Integer nodeRelation;

    /**
     * 节点展示值
     */
    private String text;

    /**
     * 是否有子节点
     */
    private String hasChild;

    /**
     * 节点排序
     */
    private Integer nodeOrder;

    /**
     * X轴
     */
    private Integer nodeXAxis;

    /**
     * Y轴
     */
    private Integer nodeYAxis;

    /**
     * 展开状态 collapse/expand
     */
    private String expandState;

    /**
     * 任务状态 0.未分配 1.进行中 2.已完成
     */
    private String taskStatus;

    /**
     * 任务责任人ID
     */
    private String taskRespIds;

    /**
     * 任务责任人名称
     */
    private String taskRespNames;

    /**
     * 来自基础FMEA的工序  1：来自基础FMEA的工序
     */
    private String fromBasicProjectProcess;

    /**
     * 结构任务计划完成时间
     */
    private String taskPlanFinishDate;

    /**
     * parentId
     */
    private Long parentId;

    /**
     * 结构任务Id
     */
    private Long structureTaskId;


    public MinderTreeNode() {
    }

    public MinderTreeNode(Long id, Long extraId, Integer nodeType, Integer nodeRelation, String text, String hasChild) {
        this.id = id;
        this.extraId = extraId;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.text = text;
        this.hasChild = hasChild;
    }

    public MinderTreeNode(Long id, Long extraId, Integer nodeType, Integer nodeRelation, String text, String hasChild, Integer nodeOrder) {
        this.id = id;
        this.extraId = extraId;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.text = text;
        this.hasChild = hasChild;
        this.nodeOrder = nodeOrder;
    }

    public MinderTreeNode(Long id, Long extraId, Integer nodeType, Integer nodeRelation, String text, String hasChild, Integer nodeOrder, Integer nodeXAxis, Integer nodeYAxis) {
        this.id = id;
        this.extraId = extraId;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.text = text;
        this.hasChild = hasChild;
        this.nodeOrder = nodeOrder;
        this.nodeXAxis = nodeXAxis;
        this.nodeYAxis = nodeYAxis;
    }

    public MinderTreeNode(Long id, Long extraId, Integer nodeType, Integer nodeRelation, String text, String hasChild, Integer nodeOrder, Integer nodeXAxis, Integer nodeYAxis, String taskPlanFinishDate, Long structureTaskId) {
        this.id = id;
        this.extraId = extraId;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.text = text;
        this.hasChild = hasChild;
        this.nodeOrder = nodeOrder;
        this.nodeXAxis = nodeXAxis;
        this.nodeYAxis = nodeYAxis;
        this.taskPlanFinishDate = taskPlanFinishDate;
        this.structureTaskId = structureTaskId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getExtraId() {
        return extraId;
    }

    public void setExtraId(Long extraId) {
        this.extraId = extraId;
    }

    public Integer getNodeType() {
        return nodeType;
    }

    public void setNodeType(Integer nodeType) {
        this.nodeType = nodeType;
    }

    public Integer getNodeRelation() {
        return nodeRelation;
    }

    public void setNodeRelation(Integer nodeRelation) {
        this.nodeRelation = nodeRelation;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getHasChild() {
        return hasChild;
    }

    public void setHasChild(String hasChild) {
        this.hasChild = hasChild;
    }

    public Integer getNodeOrder() {
        return nodeOrder;
    }

    public void setNodeOrder(Integer nodeOrder) {
        this.nodeOrder = nodeOrder;
    }

    public Integer getNodeXAxis() {
        return nodeXAxis;
    }

    public void setNodeXAxis(Integer nodeXAxis) {
        this.nodeXAxis = nodeXAxis;
    }

    public Integer getNodeYAxis() {
        return nodeYAxis;
    }

    public void setNodeYAxis(Integer nodeYAxis) {
        this.nodeYAxis = nodeYAxis;
    }

    public String getExpandState() {
        return expandState;
    }

    public void setExpandState(String expandState) {
        this.expandState = expandState;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getTaskRespIds() {
        return taskRespIds;
    }

    public void setTaskRespIds(String taskRespIds) {
        this.taskRespIds = taskRespIds;
    }

    public String getTaskRespNames() {
        return taskRespNames;
    }

    public void setTaskRespNames(String taskRespNames) {
        this.taskRespNames = taskRespNames;
    }

    public String getFromBasicProjectProcess() {
        return fromBasicProjectProcess;
    }

    public void setFromBasicProjectProcess(String fromBasicProjectProcess) {
        this.fromBasicProjectProcess = fromBasicProjectProcess;
    }

    public String getTaskPlanFinishDate() {
        return taskPlanFinishDate;
    }

    public void setTaskPlanFinishDate(String taskPlanFinishDate) {
        this.taskPlanFinishDate = taskPlanFinishDate;
    }

    public Long getStructureTaskId() {
        return structureTaskId;
    }

    public void setStructureTaskId(Long structureTaskId) {
        this.structureTaskId = structureTaskId;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }
}
