package com.enjoy.common.core.domain;

import com.enjoy.common.annotation.Excel;

import java.io.Serializable;
import java.util.List;

/**
 * 关系网 实体
 *
 * @author outian
 * @date 2021/11/29
 */
public class NetworkTreeNode implements Serializable {
    private static final long serialVersionUID = -8136388568849831017L;

    /**
     * 展示值
     */
    String text;
    /**
     * 节点类型
     */
    private Integer nodeType;

    public NetworkTreeNode(String text, Integer nodeType) {
        this.text = text;
        this.nodeType = nodeType;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getNodeType() {
        return nodeType;
    }

    public void setNodeType(Integer nodeType) {
        this.nodeType = nodeType;
    }
}
