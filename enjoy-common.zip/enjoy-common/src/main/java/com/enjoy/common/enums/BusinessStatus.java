package com.enjoy.common.enums;

/**
 * 操作状态
 *
 * @author enjoy
 *
 */
public enum BusinessStatus
{
    /**
     * 成功
     */
    SUCCESS,

    /**
     * 失败
     */
    FAIL,
}
