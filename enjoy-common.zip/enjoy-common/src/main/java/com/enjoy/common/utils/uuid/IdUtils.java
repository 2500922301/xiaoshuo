package com.enjoy.common.utils.uuid;

import java.util.UUID;

/**
 * ID生成器工具类
 *
 * @author enjoy
 */
public class IdUtils
{
    /**
     * 获取随机UUID，使用性能更好的ThreadLocalRandom生成UUID
     *
     * @return 随机UUID
     */
    public static String fastuuid()
    {
        return  UUID.randomUUID().toString();
    }
}
