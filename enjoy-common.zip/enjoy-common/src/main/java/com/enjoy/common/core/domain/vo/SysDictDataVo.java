package com.enjoy.common.core.domain.vo;

import com.enjoy.common.annotation.Excel;

public class SysDictDataVo {

    /** 字典标签 */
    @Excel(name = "*字典标签")
    private String dictLabel;

    /**
     * 字典键值
     */
    @Excel(name = "*字典键值")
    private String dictValue;

    /**
     * 样式属性（其他样式扩展）
     */
    @Excel(name = "样式属性")
    private String cssClass;

    /**
     * 字典排序
     */
    @Excel(name = "*字典排序", cellType = Excel.ColumnType.NUMERIC)
    private Long dictSort;

    /**
     * 表格字典样式
     */
    @Excel(name = "*回显样式",readConverterExp = "default=默认,primary=主要,success=成功,info=信息,warning=警告,danger=危险")
    private String listClass;

    /**
     * 字典类型
     */
    @Excel(name = "备注")
    private String remark;

    public String getDictLabel() {
        return dictLabel;
    }

    public void setDictLabel(String dictLabel) {
        this.dictLabel = dictLabel;
    }

    public String getDictValue() {
        return dictValue;
    }

    public void setDictValue(String dictValue) {
        this.dictValue = dictValue;
    }

    public String getCssClass() {
        return cssClass;
    }

    public void setCssClass(String cssClass) {
        this.cssClass = cssClass;
    }

    public Long getDictSort() {
        return dictSort;
    }

    public void setDictSort(Long dictSort) {
        this.dictSort = dictSort;
    }

    public String getListClass() {
        return listClass;
    }

    public void setListClass(String listClass) {
        this.listClass = listClass;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
