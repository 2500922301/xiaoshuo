package com.enjoy.common.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

/**
 * 明细工具类
 *
 * @author enjoy
 */
public class DetailUtils {
    /**
     * 通用列合并
     *
     * @param list       可传入List<Map<String, Object>> 或者 List<实体>
     * @param mergeCells 合并的列
     * @param saveMerges 储存合并数
     */
    public static void formatMerges(List<?> list, String[] mergeCells, String[] saveMerges) {
        if (null != list && list.size() > 0) {
            // 基准
            int[] basics = new int[mergeCells.length];
            Arrays.fill(basics, 0);
            for (int i = 0; i < list.size(); ) {
                // 合并单元格数
                int[] merges = new int[mergeCells.length];
                Arrays.fill(merges, 1);

                // 跳到下一合并组
                boolean isNextGroup = false;

                for (int j = i + 1; j < list.size(); j++) {
                    for (int m = 0; m < mergeCells.length; m++) {
                        Object current = formatMergesForGet(list.get(basics[m]), mergeCells[m]);
                        Object child = formatMergesForGet(list.get(j), mergeCells[m]);
                        if (Objects.equals(current, child)) {
                            merges[m] = merges[m] + 1;
                        } else {
                            for (int index = m; index < mergeCells.length; index++) {
                                formatMergesForSet(list.get(basics[index]), saveMerges[index], merges[index]);
                                if (m != 0) {
                                    merges[index] = 1;
                                }
                                basics[index] = j;
                        }
                        if (m == 0) {
                            isNextGroup = true;
                        }
                            break;
                        }
                    }
                    if (isNextGroup) {
                        break;
                    }
                }

                for (int index = 0; index < mergeCells.length; index++) {
                    formatMergesForSet(list.get(basics[index]), saveMerges[index], merges[index]);
                }
                i = i + merges[0];
            }
        }
    }


    /**
     * 按分组key合并单元格（支持依赖字段校验）
     *
     * @param list            数据列表
     * @param keyField        分组字段
     * @param mergeCells      合并的列
     * @param saveMerges      储存合并数
     * @param dependentFields 依赖字段映射，key为当前列字段名，value为需要额外校验的依赖字段名。
     *                        例如：{"riskStatusId": "failureReasonId", "optRiskStatusId": "failureReasonId"}
     *                        表示riskStatusId合并时还需failureReasonId相同或下一行failureReasonId为空
     */
    public static void formatMergeFmeaTableGroupByKey(List<?> list, String keyField, String[] mergeCells, String[] saveMerges, Map<String, String> dependentFields) {

        if (null == list || list.isEmpty()) return;

        // 1. 按 key 分组，保持原有顺序（LinkedHashMap 保序）
        Map<Object, List<Object>> groups = new LinkedHashMap<>();
        for (Object item : list) {
            Object key = formatMergesForGet(item, keyField); // 取出 key 值 (0,1,2,3,4)
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(item);
        }

        // 2. 每个分组内部独立执行合并逻辑
        for (Map.Entry<Object, List<Object>> entry : groups.entrySet()) {
            List<Object> groupList = entry.getValue();
            formatMergeFmeaTable(groupList, mergeCells, saveMerges, dependentFields);
        }

        // 注意：由于 Java 引用传递的特性，原 list 中的对象已被直接修改，
        // 无需将 groupList 写回 list

    }

    public static void formatMergeFmeaTable(List<?> list, String[] mergeCells, String[] saveMerges, Map<String, String> dependentFields) {
        if (null != list && list.size() > 0) {
            // 基准
            int[] basics = new int[mergeCells.length];
            Arrays.fill(basics, 0);
            for (int i = 0; i < list.size(); ) {
                // 合并单元格数
                int[] merges = new int[mergeCells.length];
                Arrays.fill(merges, 1);

                // 跳到下一合并组
                boolean isNextGroup = false;

                for (int j = i + 1; j < list.size(); j++) {
                    for (int m = 0; m < mergeCells.length; m++) {
                        Object current = formatMergesForGet(list.get(basics[m]), mergeCells[m]);
                        Object child = formatMergesForGet(list.get(j), mergeCells[m]);
                        // 合并条件：
                        // 1. 当前id和下一id相同（两者非空且相等）
                        // 2. 当前id非空，下一id为空
                        // 3. 当前id和下一id都为空
                        // 不合并：当前id为空，下一id不为空
                        boolean canMerge = canMergeValue(current, child);

                        // 如果当前列配置了依赖字段，还需校验依赖字段是否满足合并条件
                        // 例如：riskStatusId 依赖 failureReasonId，两者是并且关系
                        if (canMerge && dependentFields != null) {
                            String depField = dependentFields.get(mergeCells[m]);
                            if (depField != null) {
                                Object depCurrent = formatMergesForGet(list.get(basics[m]), depField);
                                Object depChild = formatMergesForGet(list.get(j), depField);
                                canMerge = canMergeValue(depCurrent, depChild);
                            }
                        }

                        if (canMerge) {
                            merges[m] = merges[m] + 1;
                        } else {
                            // 当前id和下一id不同，不合并，保存当前列的合并数
                            formatMergesForSet(list.get(basics[m]), saveMerges[m], merges[m]);
                            merges[m] = 1;
                            basics[m] = j;
                            if (m == 0) {
                                // 第一列不同，跳到下一组
                                isNextGroup = true;
                                break;
                            }
                            // 非第一列不同，不跳到下一组，继续校验下一列是否有合并的情况
                        }
                    }
                    if (isNextGroup) {
                        break;
                    }
                }

                for (int index = 0; index < mergeCells.length; index++) {
                    formatMergesForSet(list.get(basics[index]), saveMerges[index], merges[index]);
                }
                i = i + merges[0];
            }
        }
    }

    /**
     * 判断两个值是否满足合并条件
     * 合并：相同 / 当前非空下一为空 / 都为空
     * 不合并：当前为空下一非空 / 两者非空但不同
     */
    private static boolean canMergeValue(Object current, Object child) {
        boolean currentEmpty = isEmptyValue(current);
        boolean childEmpty = isEmptyValue(child);
        return (!currentEmpty && !childEmpty && Objects.equals(current, child))
                || (!currentEmpty && childEmpty)
                || (currentEmpty && childEmpty);
    }

    /**
     * 判断字段值是否为空（null、空字符串、纯空白）
     */
    private static boolean isEmptyValue(Object value) {
        if (value == null) {
            return true;
        }
        if (value instanceof String) {
            return ((String) value).trim().isEmpty();
        }
        return false;
    }

    private static Object formatMergesForGet(Object item, String fieldName) {
        try {
            if (item instanceof Map) {
                Map<String, Object> map = (Map<String, Object>) item;
                return map.get(fieldName);
            } else {
                Method method = item.getClass().getMethod("get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1));
                return method.invoke(item, new Object[0]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void formatMergesForSet(Object item, String fieldName, int value) {
        try {
            if (item instanceof Map) {
                Map<String, Object> map = (Map<String, Object>) item;
                map.put(fieldName, value);
            } else {
                Class[] parameterTypes = new Class[1];
                Field field = item.getClass().getDeclaredField(fieldName);
                parameterTypes[0] = field.getType();
                Method method = item.getClass().getMethod("set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1), parameterTypes);
                method.invoke(item, new Object[]{value});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
