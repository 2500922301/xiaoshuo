package com.enjoy.common.enums;

/**
 * 用户状态
 *
 * @author enjoy
 */
public enum UserStatus
{
    /**
     * OK
     */
    OK("0", "正常"),
    /**
     * DISABLE
     */
    DISABLE("1", "停用"),
    /**
     * DELETED
     */
    DELETED("1", "删除");

    private final String code;
    private final String info;

    /**
     * 构造方法
     * @param code 编码
     * @param info 信息
     */
    UserStatus(String code, String info)
    {
        this.code = code;
        this.info = info;
    }

    /**
     * 获取 编号
     * @return  String
     */
    public String getCode()
    {
        return code;
    }

    /**
     * 获取 信息
     * @return String
     */
    public String getInfo()
    {
        return info;
    }
}
