package com.enjoy.common.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.BigDecimal;

import com.enjoy.common.utils.poi.ExcelHandlerAdapter;
import org.apache.poi.ss.usermodel.IndexedColors;

/**
 * 自定义导出Excel数据注解
 *
 * @author enjoy
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Excel
{
    /**
     * 导出时在excel中排序
     */
    public int sort() default Integer.MAX_VALUE;

    /**
     * 导出到Excel中的名字.
     */
    public String name() default "";

    /**
     * 隐藏列
     */
    public boolean isColumnHidden() default false;

    /**
     * 标题背景颜色
     */
    public IndexedColors headerBackgroundColor() default IndexedColors.GREY_50_PERCENT;

    /**
     * 日期格式, 如: yyyy-MM-dd
     */
    public String dateFormat() default "";

    /**
     * 如果是字典类型，请设置字典的type值 (如: sys_user_sex)
     */
    public String dictType() default "";

    /**
     * 读取内容转表达式 (如: 0=男,1=女,2=未知)
     */
    public String readConverterExp() default "";

    /**
     * 分隔符，读取字符串组内容
     */
    public String separator() default ",";

    /**
     * BigDecimal 精度 默认:-1(默认不开启BigDecimal格式化)
     */
    public int scale() default -1;

    /**
     * BigDecimal 舍入规则 默认:BigDecimal.ROUND_HALF_EVEN
     */
    public int roundingMode() default BigDecimal.ROUND_HALF_EVEN;

    /**
     * 导出类型（0数字 1字符串）
     */
    public ColumnType cellType() default ColumnType.STRING;

    /**
     * 导出时在excel中每个列的高度 单位为字符
     */
    public double height() default 14;

    /**
     * 导出时在excel中每个列的宽 单位为字符
     */
    public double width() default 16;

    /**
     * 文字后缀,如% 90 变成90%
     */
    public String suffix() default "";

    /**
     * 当值为空时,字段的默认值
     */
    public String defaultValue() default "";

    /**
     * 提示信息
     */
    public String prompt() default "";

    /**
     * 设置只能选择不能输入的列内容.
     */
    public String[] combo() default {};

    /**
     * 只能选择字典值
     * @return
     */
    public String comboDictType() default "";

    /**
     * 是否导出数据,应对需求:有时我们需要导出一份模板,这是标题需要但内容需要用户手工填写.
     */
    public boolean isExport() default true;

    /**
     * 另一个类中的属性名称,支持多级获取,以小数点隔开
     */
    public String targetAttr() default "";

    /**
     * 是否自动统计数据,在最后追加一行统计数据总和
     */
    public boolean isStatistics() default false;

    /**
     * 导出字段对齐方式（0：默认；1：靠左；2：居中；3：靠右）
     */
    public Align align() default Align.AUTO;

    /**
     * 自定义数据处理器
     */
    public Class<?> handler() default ExcelHandlerAdapter.class;

    /**
     * 自定义数据处理器参数
     */
    public String[] args() default {};
    /**
     * 导出到Excel中的顺序编号
     */
    public int orderNum() default 0;

    /**
     * 自定义线
     */
    public enum Align {
        /**
         * 定义 value 0
         */
        AUTO(0),
        /**
         *  定义 LEFT 1
         */
        LEFT(1),
        /**
         * 定义 CENTER 2
         */
        CENTER(2),
        /**
         * 定义 RIGHT 3
         */
        RIGHT(3);
        /**
         * 定义 value
         */
        private final int value;

        /**
         * 初始化
         * @param value
         */
        Align(int value)
        {
            this.value = value;
        }

        /**
         * 获取 值
         * @return int
         */
        public int value()
        {
            return this.value;
        }
    }

    /**
     * 字段类型（0：导出导入；1：仅导出；2：仅导入）
     */
    Type type() default Type.ALL;

    /**
     * 自定义类型
     */
    public enum Type
    {
        /**
         * ALL
         */
        ALL(0),
        /**
         * EXPORT
         */
        EXPORT(1),
        /**
         * IMPORT
         */
        IMPORT(2);
        private final int value;

        /**
         * 构造方法
         * @param value
         */
        Type(int value)
        {
            this.value = value;
        }

        /**
         *  获取 value
         * @return   int
         */
        public int value()
        {
            return this.value;
        }
    }

    /**
     * 自定义列 类型
     */
    public enum ColumnType
    {
        /**
         * NUMERIC
         */
        NUMERIC(0),
        /**
         * STRING
         */
        STRING(1),
        /**
         * IMAGE
         */
        IMAGE(2);
        private final int value;

        /**
         * 构造方法
         * @param value
         */
        ColumnType(int value)
        {
            this.value = value;
        }

        /**
         * 获取值
         * @return int
         */
        public int value()
        {
            return this.value;
        }

    }
}
