package com.enjoy.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 读取项目相关配置
 *
 * @author enjoy
 */
@Component
@ConfigurationProperties(prefix = "enjoy")
public class EnjoyConfig {
    /**
     * 项目名称
     */
    private String name;

    /**
     * 版本
     */
    private String version;

    /**
     * 版权年份
     */
    private String copyrightYear;

    /**
     * 实例演示开关
     */
    private boolean demoEnabled;

    /**
     * 上传路径
     */
    private static String profile;

    /**
     * 获取地址开关
     */
    private static boolean addressEnabled;

    /**
     * rsa
     */
    private static String pri;

    /**
     * 中台地址
     */
    private static String middleOfficeAddress;

    /**
     * 中台APPID
     */
    private static String appId;
    /**
     * 中台APPKEY
     */
    private static String appKey;

    /**
     * 启用数据库和Redis密码加密
     */
    private boolean enableEncryption;

    /**
     * 文件存储方式
     */
    private static String fileStorage;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCopyrightYear() {
        return copyrightYear;
    }

    public void setCopyrightYear(String copyrightYear) {
        this.copyrightYear = copyrightYear;
    }

    public boolean isDemoEnabled() {
        return demoEnabled;
    }

    public void setDemoEnabled(boolean demoEnabled) {
        this.demoEnabled = demoEnabled;
    }

    public static String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        EnjoyConfig.profile = profile;
    }

    public static boolean isAddressEnabled() {
        return addressEnabled;
    }

    public void setAddressEnabled(boolean addressEnabled) {
        EnjoyConfig.addressEnabled = addressEnabled;
    }

    public String getPri() {
        return pri;
    }

    public void setPri(String pri) {
        EnjoyConfig.pri = pri;
    }

    public boolean isEnableEncryption() {
        return enableEncryption;
    }

    public void setEnableEncryption(boolean enableEncryption) {
        this.enableEncryption = enableEncryption;
    }

    public static String getFileStorage() {
        return fileStorage;
    }

    public void setFileStorage(String fileStorage) {
        EnjoyConfig.fileStorage = fileStorage;
    }

    public String getMiddleOfficeAddress() {
        return middleOfficeAddress;
    }

    public void setMiddleOfficeAddress(String middleOfficeAddress) {
        EnjoyConfig.middleOfficeAddress = middleOfficeAddress;
    }

    public String getAppId() {
        return appId;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        EnjoyConfig.appKey = appKey;
    }

    public void setAppId(String appId) {
        EnjoyConfig.appId = appId;
    }

    /**
     * 获取导入上传路径
     */
    public static String getImportPath() {
        return getProfile() + "/import";
    }

    /**
     * 获取头像上传路径
     */
    public static String getAvatarPath() {
        return getProfile() + "/avatar";
    }

    /**
     * 获取下载路径
     */
    public static String getDownloadPath() {
        return getProfile() + "/download/";
    }

    /**
     * 获取上传路径
     */
    public static String getUploadPath() {
        return getProfile() + "/upload";
    }
}
