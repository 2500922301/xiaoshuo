package com.enjoy.common.core.domain;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 关系网
 *
 * @author outian
 * @date 2021/11/29
 */
public class NetworkTree implements Serializable {
    private static final long serialVersionUID = -8136388568849831017L;

    /**
     * 关系ID
     */
    private Long id;

    /**
     * 节点方向
     * <p>
     * 常量 FmeaConstants.NETWORK_DIRECTION_LEFT
     */
    private String direction;

    /**
     * 展示信息
     */
    private List<NetworkTreeNode> data;

    /**
     * 子节点
     */
    private List<NetworkTree> children;

    private String dvpIds;

    private String dvpNames;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date optPreventDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date optDetectionDate;

    private Long structureId;

    private String ids;

    public NetworkTree() {
    }

    public NetworkTree(List<NetworkTreeNode> data, List<NetworkTree> children) {
        this.data = data;
        this.children = children;
    }

    public NetworkTree(Long id, List<NetworkTreeNode> data, List<NetworkTree> children) {
        this.id = id;
        this.data = data;
        this.children = children;
    }

    public NetworkTree(Long id, Long structureId, List<NetworkTreeNode> data, List<NetworkTree> children) {
        this.id = id;
        this.structureId = structureId;
        this.data = data;
        this.children = children;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public List<NetworkTreeNode> getData() {
        return data;
    }

    public void setData(List<NetworkTreeNode> data) {
        this.data = data;
    }

    public List<NetworkTree> getChildren() {
        return children;
    }

    public void setChildren(List<NetworkTree> children) {
        this.children = children;
    }

    public Date getOptPreventDate() {
        return optPreventDate;
    }

    public void setOptPreventDate(Date optPreventDate) {
        this.optPreventDate = optPreventDate;
    }

    public Date getOptDetectionDate() {
        return optDetectionDate;
    }

    public void setOptDetectionDate(Date optDetectionDate) {
        this.optDetectionDate = optDetectionDate;
    }

    public String getDvpIds() {
        return dvpIds;
    }

    public void setDvpIds(String dvpIds) {
        this.dvpIds = dvpIds;
    }

    public String getDvpNames() {
        return dvpNames;
    }

    public void setDvpNames(String dvpNames) {
        this.dvpNames = dvpNames;
    }

    public Long getStructureId() {
        return structureId;
    }

    public void setStructureId(Long structureId) {
        this.structureId = structureId;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }
}
