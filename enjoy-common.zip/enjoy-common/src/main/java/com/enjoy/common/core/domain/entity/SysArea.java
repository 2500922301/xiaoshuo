package com.enjoy.common.core.domain.entity;

import com.enjoy.common.annotation.Excel;
import com.enjoy.common.core.domain.BaseEntity;

/**
 * 领域表
 */
public class SysArea extends BaseEntity {
    private static final long serialVersionUID = 1L;



    /**
     * 领域ID
     */
    private Long areaId;

    /**
     * code
     */
    private String code;
    /**
     * 领域名称
     */
    private String areaName;

    public SysArea(Long areaId, String code, String areaName) {
        this.areaId = areaId;
        this.code = code;
        this.areaName = areaName;
    }

    public Long getAreaId() {
        return areaId;
    }

    public void setAreaId(Long areaId) {
        this.areaId = areaId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
}
