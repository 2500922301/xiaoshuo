package com.enjoy.common.core.domain.vo;

import com.enjoy.common.annotation.Excel;
import com.enjoy.common.annotation.Excel.Type;
import com.enjoy.common.annotation.Excels;
import com.enjoy.common.core.domain.entity.SysDept;

import java.util.Date;

/**
 * 用户
 *
 * @author enjoy
 */
public class SysUserVo {

    /**
     * 用户账号
     */
    @Excel(name = "*用户名" ,orderNum = 1)
    private String userName;

    /**
     * 姓名
     */
    @Excel(name = "*姓名", orderNum = 3)
    private String realName;

    /**
     * 组织名称
     */
    private String organizeName;

    /**
     * 用户邮箱
     */
    @Excel(name = "邮箱" ,orderNum = 4)
    private String email;

    /**
     * 手机号码
     */
    //@Excel(name = "手机号码")
    private String phonenumber;

    /**
     * 工号
     */
    @Excel(name = "*工号", orderNum = 2)
    private String jobNum;

    /**
     * 角色
     */
    @Excel(name = "角色\n(多个角色换行隔开)")
    private String postName;
    /**
     * 用户性别
     */
    //@Excel(name = "用户性别\n(男/女/未知)", readConverterExp = "0=男,1=女,2=未知")
    private String sex;

    /**
     * 帐号状态（0正常 1停用）
     */
    @Excel(name = "*帐号状态\n(正常/停用)", readConverterExp = "0=正常,1=停用", orderNum = 5)
    private String status;


    /**
     * 最后登录IP
     */
    //@Excel(name = "最后登录IP", type = Type.EXPORT, orderNum = 7)
    private String loginIp;

    /**
     * 最后登录时间
     */
    @Excel(name = "最后登录时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss", type = Type.EXPORT, orderNum = 8)
    private Date loginDate;

    /**
     * 部门对象
     */
    //@Excels({
    //        @Excel(name = "部门名称", targetAttr = "deptName", type = Type.EXPORT),
    //        @Excel(name = "部门负责人", targetAttr = "leader", type = Type.EXPORT)
    //})
    private SysDept dept;

    @Excel(name = "领域", orderNum = 6)
    private String fieldNames;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getOrganizeName() {
        return organizeName;
    }

    public void setOrganizeName(String organizeName) {
        this.organizeName = organizeName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getJobNum() {
        return jobNum;
    }

    public void setJobNum(String jobNum) {
        this.jobNum = jobNum;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public void setLoginIp(String loginIp) {
        this.loginIp = loginIp;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }

    public SysDept getDept() {
        return dept;
    }

    public void setDept(SysDept dept) {
        this.dept = dept;
    }

    public String getFieldNames() {
        return fieldNames;
    }

    public void setFieldNames(String fieldNames) {
        this.fieldNames = fieldNames;
    }
}
