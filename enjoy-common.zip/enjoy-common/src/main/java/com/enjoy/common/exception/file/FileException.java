package com.enjoy.common.exception.file;

import com.enjoy.common.exception.base.BaseException;

/**
 * 文件信息异常类
 *
 * @author enjoy
 */
public class FileException extends BaseException
{
    private static final long serialVersionUID = 1L;

    public FileException(String code, Object[] args)
    {
        super("file", code, args, null);
    }

}
