package com.enjoy.common.core.domain;

import java.io.Serializable;
import java.util.List;

/**
 * 脑图树 实体
 *
 * @author outian
 * @date 2021/11/29
 */
public class MinderTree implements Serializable {
    private static final long serialVersionUID = -7788640966064001036L;

    /**
     * 脑图节点
     */
    private MinderTreeNode data;

    /**
     * 脑图子节点
     */
    private List<MinderTree> children;

    private String remind;

    public MinderTree() {
    }

    public MinderTree(MinderTreeNode data, List<MinderTree> children) {
        this.data = data;
        this.children = children;
    }

    public MinderTreeNode getData() {
        return data;
    }

    public void setData(MinderTreeNode data) {
        this.data = data;
    }

    public List<MinderTree> getChildren() {
        return children;
    }

    public void setChildren(List<MinderTree> children) {
        this.children = children;
    }

    public String getRemind() {
        return remind;
    }

    public void setRemind(String remind) {
        this.remind = remind;
    }
}
