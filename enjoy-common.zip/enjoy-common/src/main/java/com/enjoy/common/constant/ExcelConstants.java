package com.enjoy.common.constant;

public class ExcelConstants {

    /**
     * 组织导入模板sheetName
     */
    public static final String TMORGANIZE_IMPORT_TABLE_SHEET = "组织导入模板";

    /**
     * 组织导入模板标题头
     */
    public static final String[] TMORGANIZE_IMPORT_TABLE_HEADER = new String[]{"*组织编码", "*组织名称", "组织(标准库)", "备注"};


    /**
     * 产品线导入模板sheetName
     */
    public static final String TMPRODUCTLINE_IMPORT_TABLE_SHEET = "产品线导入模板";

    /**
     * 产品线导入模板标题头
     */
    public static final String[] TMPRODUCTLINE_IMPORT_TABLE_HEADER = new String[] {"*组织","*产品线名称","备注"};

    /**
     * 产品小类导入模板sheetName
     */
    public static final String TMPRODUCTCLASS_IMPORT_TABLE_SHEET = "产品小类导入模板";

    /**
     * 产品小类导入模板标题头
     */
    public static final String[] TMPRODUCTCLASS_IMPORT_TABLE_HEADER = new String[] {"*组织","*产品线名称","*产品小类代码","*产品小类名称","备注"};

    /**
     * 产品导入模板sheetName
     */
    public static final String TMPRODUCT_IMPORT_TABLE_SHEET = "产品导入模板";

    /**
     * 产品导入模板标题头
     */
    public static final String[] TMPRODUCT_IMPORT_TABLE_HEADER = new String[] {"*组织","*产品线","产品小类","*产品编码","*产品名称","产品版本","*产品状态","备注"};

    /**
     * 物料小类导入模板sheetName
     */
    public static final String MATERIALCLASS_IMPORT_TABLE_SHEET = "物料小类导入模板";

    /**
     * 物料小类导入模板标题头
     */
    public static final String[] MATERIALCLASS_IMPORT_TABLE_HEADER = new String[] {"*物料小类代码","*物料小类名称","品类名称","备注"};

    /**
     * 物料导入模板sheetName
     */
    public static final String MATERIAL_IMPORT_TABLE_SHEET = "物料导入模板";

    /**
     * 物料导入模板标题头
     */
    public static final String[] MATERIAL_IMPORT_TABLE_HEADER = new String[]{"物料小类", "*物料编码", "*物料名称", "品类名称", "物料版本", "物料状态", "备注"};

    /**
     * 物料供应商导入模板sheetName
     */
    public static final String SUPPLIER_IMPORT_TABLE_SHEET = "物料供应商导入模板";

    /**
     * 物料供应商导入模板标题头
     */
    public static final String[] SUPPLIER_IMPORT_TABLE_HEADER = new String[]{"*物料供应商编码", "*物料供应商名称", "物料供应商类别", "制造商名称", "物料工厂编码", "物料工厂名称", "备注"};

    /**
     * 工厂导入模板sheetName
     */
    public static final String FACTORY_IMPORT_TABLE_SHEET = "工厂导入模板";

    /**
     * 工厂导入模板标题头
     */
    public static final String[] FACTORY_IMPORT_TABLE_HEADER = new String[]{"*组织", "*工厂编码", "*工厂类别", "*工厂名称", "*线体名称", "备注"};

    /**
     * 特性符号导入模板sheetName
     */
    public static final String SYMBOL_IMPORT_TABLE_SHEET = "特性符号导入模板";

    /**
     * 特性符号导入模板标题头
     */
    public static final String[] SYMBOL_IMPORT_TABLE_HEADER = new String[]{"*符号", "特性类型","特性分类", "严重度下限", "严重度上限", "发生度下限", "发生度上限", "探测度下限", "探测度上限", "AP", "备注"};

    /**
     * 评价测量技术导入模板sheetName
     */
    public static final String MEASURINGTECHNIQUE_IMPORT_TABLE_SHEET = "评价测量技术导入模板";

    /**
     * 评价测量技术导入模板标题头
     */
    public static final String[] MEASURINGTECHNIQUE_IMPORT_TABLE_HEADER = new String[]{"*分类", "*描述", "备注"};

    /**
     * 工序导入模板sheetName
     */
    public static final String PROCESS_IMPORT_TABLE_SHEET = "工序步骤导入模板";

    /**
     * 覆盖导入模板
     */
    public static final String COVER_DATA_IMPORT_TABLE_SHEET = "覆盖导入模板";

    /**
     * 工序导入模板标题头
     */
    public static final String[] PROCESS_IMPORT_TABLE_HEADER = new String[]{"*工序/步骤类型", "*组织", "*产品线", "*类别", "*工序/步骤编号", "*工序/步骤名称", "备注"};

    public static final String[] COVER_DATA_TABLE_HEADER = new String[]{"编号", "覆盖编号"};

    /**
     * 步骤导入模板sheetName
     */
    public static final String STEP_IMPORT_TABLE_SHEET = "步骤导入模板";

    /**
     * 步骤导入模板标题头
     */
    public static final String[] STEP_IMPORT_TABLE_HEADER = new String[]{"组织", "产品线", "*步骤编号","*步骤名称"};

    /**
     * 要素导入模板sheetName
     */
    public static final String ELEMENT_IMPORT_TABLE_SHEET = "要素导入模板";

    /**
     * 要素导入模板标题头
     */
    public static final String[] ELEMENT_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*分类","*要素名称", "备注"};

    /**
     * 过程项目/过程步骤功能导入模板sheetName
     */
    public static final String PROCESS_FUNCTION_IMPORT_TABLE_SHEET = "过程项目过程步骤功能导入模板";

    /**
     * 过程项目/过程步骤功能导入模板标题头
     */
    public static final String[] PROCESS_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*描述", "备注"};

    /**
     * 要素功能导入模板sheetName
     */
    public static final String ELEMENT_FUNCTION_IMPORT_TABLE_SHEET = "要素功能导入模板";

    /**
     * 要素功能导入模板标题头
     */
    public static final String[] ELEMENT_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*描述", "备注"};

    /**
     * 过程项目/过程步骤失效导入模板sheetName
     */
    public static final String PROCESS_FAILURE_FUNCTION_IMPORT_TABLE_SHEET = "过程项目过程步骤失效导入模板";


    /**
     * 过程项目/过程步骤失效导入模板标题头
     */
    public static final String[] PROCESS_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "失效分类", "严重度", "失效率", "维修报废成本", "器件编码", "*描述", "备注"};

    /**
     * 要素失效导入模板sheetName
     */
    public static final String ELEMENT_FAILURE_FUNCTION_IMPORT_TABLE_SHEET = "要素失效导入模板";


    /**
     * 要素失效导入模板标题头
     */
    public static final String[] ELEMENT_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "失效分类", "失效率", "维修报废成本", "器件编码", "*描述", "备注"};

    /**
     * 预防措施导入模板sheetName
     */
    public static final String PREVENT_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_SHEET = "预防措施导入模板";


    /**
     * 预防措施导入模板标题头
     */
    public static final String[] PREVENT_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*BU", "*领域", "发生度", "*描述", "备注"};

    /**
     * 预防措施导入模板标题头
     */
    public static final String[] MF_PREVENT_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "分类", "发生度", "*描述", "备注"};


    /**
     * 探测措施导入模板sheetName
     */
    public static final String DETECTION_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_SHEET = "探测措施导入模板";


    /**
     * 探测措施导入模板标题头
     */
    public static final String[] DETECTION_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*BU", "*领域", "探测度", "*描述", "备注"};

    /**
     * 诊断库导入模板标题头
     */
    public static final String[] DIAGNOSIS_IMPORT_TABLE_HEADER = new String[]{"*BU", "*领域", "*描述", "备注"};

    /**
     * 诊断库导入模板sheetName
     */
    public static final String DIAGNOSIS_IMPORT_TABLE_SHEET = "诊断库导入模板";

    /**
     * 系统响应导入模板标题头
     */
    public static final String[] SYSTEM_RESPONSE_IMPORT_TABLE_HEADER = new String[]{"*BU", "*领域", "*描述", "备注"};

    /**
     * 系统响应导入模板sheetName
     */
    public static final String SYSTEM_RESPONSE_IMPORT_TABLE_SHEET = "系统响应导入模板";


    /**
     * 探测措施导入模板标题头
     */
    public static final String[] MF_DETECTION_MEASURE_FAILURE_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "分类", "探测度", "*描述", "备注"};


    /**
     * 零件导入模板sheetName
     */
    public static final String BOM__IMPORT_TABLE_SHEET = "零件导入模板";


    /**
     * 零件导入模板标题头
     */
    public static final String[] BOM_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*零件名", "备注"};

    /**
     * 零件导入模板标题头
     */
    public static final String[] MF_BOM_IMPORT_TABLE_HEADER = new String[]{"*组织", "*零件名", "备注"};

    /**
     * 产品功能导入模板sheetName
     */
    public static final String PRODUCT_FUNCTION__IMPORT_TABLE_SHEET = "产品功能导入模板";


    /**
     * 产品功能导入模板标题头
     */
    public static final String[] PRODUCT_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*描述", "备注"};

    /**
     * 产品功能导入模板标题头
     */
    public static final String[] MF_PRODUCT_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*描述", "备注"};

    /**
     * 零件功能导入模板sheetName
     */
    public static final String BOM_FUNCTION__IMPORT_TABLE_SHEET = "零件功能导入模板";

    /**
     * 零件功能导入模板标题头
     */
    public static final String[] BOM_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "*描述", "备注"};

    /**
     * 零件功能导入模板标题头
     */
    public static final String[] MF_BOM_FUNCTION_IMPORT_TABLE_HEADER = new String[]{"*组织", "*描述", "备注"};

    /**
     * 产品失效导入模板sheetName
     */
    public static final String PRODUCT_FAILURE__IMPORT_TABLE_SHEET = "产品失效导入模板";


    /**
     * 产品失效导入模板标题头
     */
    public static final String[] PRODUCT_FAILURE_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "失效分类", "严重度", "*描述", "备注"};

    /**
     * 产品失效导入模板标题头
     */
    public static final String[] MF_PRODUCT_FAILURE_IMPORT_TABLE_HEADER = new String[]{"*组织", "失效分类", "严重度", "*描述", "备注"};


    /**
     * 零件失效导入模板sheetName
     */
    public static final String BOM_FAILURE__IMPORT_TABLE_SHEET = "零件失效导入模板";


    /**
     * 零件失效导入模板标题头
     */
    public static final String[] BOM_FAILURE_IMPORT_TABLE_HEADER = new String[]{"*组织", "*产品线", "失效分类", "严重度", "*描述", "备注"};

    /**
     * 零件失效导入模板标题头
     */
    public static final String[] MF_BOM_FAILURE_IMPORT_TABLE_HEADER = new String[]{"*组织", "失效分类", "严重度", "*描述", "备注"};


    /**
     * DVP导入模板sheetName
     */
    public static final String DVP__IMPORT_TABLE_SHEET = "DVP导入模板";

    /**
     * DVP导入模板标题头
     */
    public static final String[] DVP_IMPORT_TABLE_HEADER = new String[]{"*实验项目", "*实验名称", "实验方法", "目标要求", "试验类型", "样品数量", "试验地址", "计划开始时间", "样件状态", "试验状态", "试验报告", "备注"};

    /**
     * PFMEA特性清单导出标题头
     */
    public static final String[] PFMEA_FEATURE_LIST_TABLE_HEADER = new String[]{"序号", "特性编号", "工序", "步骤", "编码", "特性类型", "特性小类", "标准名称", "分类因素/场景分类", "定量基准值", "定量下限", "定量上限", "定量单位", "定量规格描述", "特性符号"};

    /**
     * DFMEA特性清单导出标题头
     */
    //public static final String[] DFMEA_FEATURE_LIST_TABLE_HEADER = new String[]{"序号", "特性编号", "零件", "编码", "特性小类", "标准名称", "分类因素/场景分类", "定量基准值", "定量下限", "定量上限", "定量单位", "定量规格描述", "特性符号"};
    public static final String[] DFMEA_FEATURE_LIST_TABLE_HEADER = new String[]{"序号", "结构", "特性编号", "编码", "特性名称", "规范", "特殊特性"};

    /**
     *  客户标题头
     */
    public static final String[] CUSTOMER_LIST_TABLE_HEADER = new String[]{"组织编码", "组织名称", "客户编码", "客户名称", "客户LOGO", "CC", "SC", "YC", "YS", "备注", "创建者", "创建时间"};

    /**
     *  特性导入模板
     */
    public static final String CHARACTER_IMPORT_TABLE_SHEET = "特性导入模板";

    /**
     * 特性导入模板标题头
     */
    public static final String[] CHARACTER_IMPORT_TABLE_HEADER = new String[]{"*特性类型", "*一层标准名称", "*二层标准名称", "*三层标准名称",
            "*四层标准名称", "*标准名称", "*特性小类", "分类因素/场景分类", "*标准类型", "定量基准值\n(基准值上限下限至少一个不为空)", "定量上限\n(基准值上限下限至少一个不为空)",
            "定量下限\n(基准值上限下限至少一个不为空)", "定量单位\n(定量必填)", "定性规格/规格描述\n(定性必填)","备注", "检测条件/适用条件", "*组织", "*产品线", "类别", "通用属性",
            "产品小类", "具体编码", "源文件归档位置", "源文件编号", "源文件名称", "源文件版本", "源文件URL",
            "源文件状态", "缺陷代码", "步骤\n(过程特性必填)"};

    public static final String[] DF_CHARACTER_IMPORT_TABLE_HEADER = new String[]{"*一层标准名称", "*二层标准名称", "*三层标准名称",
            "*四层标准名称", "*标准名称", "*特性小类", "分类因素/场景分类", "*标准类型", "定量基准值\n(基准值上限下限至少一个不为空)", "定量上限\n(基准值上限下限至少一个不为空)",
            "定量下限\n(基准值上限下限至少一个不为空)", "定量单位\n(定量必填)", "定性规格/规格描述\n(定性必填)", "备注", "检测条件/适用条件", "*组织", "*产品线", "类别", "通用属性",
            "产品小类", "具体编码", "源文件归档位置", "源文件编号", "源文件名称", "源文件版本", "源文件URL",
            "源文件状态", "缺陷代码"};

    public static final String[] DF_CHARACTER_IMPORT_TABLE_HEADER_NEW = new String[]{"*BU", "*领域", "特殊特性", "*特性"};

    /**
     * 特性导入模板标题头
     */
    public static final String[] MF_CHARACTER_IMPORT_TABLE_HEADER = new String[]{"*一层标准名称", "*二层标准名称", "*三层标准名称",
            "*四层标准名称", "*标准名称", "*特性小类", "分类因素/场景分类", "*标准类型", "定量基准值\n(基准值上限下限至少一个不为空)", "定量上限\n(基准值上限下限至少一个不为空)",
            "定量下限\n(基准值上限下限至少一个不为空)", "定量单位\n(定量必填)", "定性规格/规格描述\n(定性必填)","备注", "检测条件/适用条件", "*组织", "类别", "通用属性",
            "产品小类", "具体编码", "源文件归档位置", "源文件编号", "源文件名称", "源文件版本", "源文件URL",
            "源文件状态", "缺陷代码"};

    /**
     * 设备导入模板sheetName
     */
    public static final String EUQIPMENT_IMPORT_TABLE_SHEET = "设备导入模板";

    /**
     * 设备导入模板标题头
     */
    public static final String[] EUQIPMENT_IMPORT_TABLE_HEADER = new String[]{"*组织", "*设备编码", "*设备名称", "设备类型", "备注"};

    /**
     * 分类因素场景分类导入模板sheetName
     */
    public static final String CLASSFACTOR_IMPORT_TABLE_SHEET = "分类因素场景分类导入模板";

    /**
     * 反应计划导入模板sheetName
     */
    public static final String RESPONSE_PLAN_IMPORT_TABLE_SHEET = "反应计划导入模板";

    /**
     * 分类因素场景分类导入模板标题头
     */
    public static final String[] CLASSFACTOR_IMPORT_TABLE_HEADER = new String[]{"*描述", "备注"};


    /**
     * 反应计划导入模板标题头
     */
    public static final String[] RESPONSE_PLAN_IMPORT_TABLE_HEADER = new String[]{"*描述", "备注"};

    /**
     * BU导入模板sheetName
     */
    public static final String BU_IMPORT_TABLE_SHEET = "BU导入模板";

    /**
     * BU导入模板标题头
     */
    public static final String[] BU_IMPORT_TABLE_HEADER = new String[]{"*BU编码", "*BU名称","*BU描述"};

    /**
     * 领域导入模板sheetName
     */
    public static final String FIELD_IMPORT_TABLE_SHEET = "领域导入模板";

    /**
     * 领域导入模板标题头
     */
    public static final String[] FIELD_IMPORT_TABLE_HEADER = new String[]{"*领域编码", "领域名称","*领域描述"};

    /**
     * 客户导入模板sheetName
     */
    public static final String CUSTOMER_IMPORT_TABLE_SHEET = "客户导入模板";

    /**
     * 客户导入模板标题头
     */
    public static final String[] CUSTOMER_IMPORT_TABLE_HEADER = new String[]{"*组织", "*客户编码","*客户名称", "备注"};

    /**
     * 整车失效库导入模板sheetName
     */
    public static final String VEHICLE_FAILURE_LIBRARY_IMPORT_TABLE_SHEET = "整车失效库导入模板";

    /**
     * 整车失效库导入模板标题头
     */
    public static final String[] VEHICLE_FAILURE_LIBRARY_HEADER = new String[]{"*BU", "*领域","*DFMEA编码", "*年型项目", "*FMEA名称", "*项目经理"};

    /**
     * BOM项目导入模板sheetName
     */
    public static final String BOM_PROJECT_IMPORT_TABLE_SHEET = "BOM导入模板";


    /**
     * BOM项目导入模板标题头
     */
    public static final String[] BOM_PROJECT_IMPORT_TABLE_HEADER = new String[]{"序号", "零件"};

    /**
     * FLOWCHART导入模板sheetName
     */
    public static final String FLOWCHART_IMPORT_TABLE_SHEET = "FlowChart导入模板";


    /**
     * FLOWCHART导入模板标题头
     */
    public static final String[] FLOWCHART_IMPORT_TABLE_HEADER = new String[]{"Flowchart ID", "工序CODE","工序名称", "步骤code", "步骤名称"};


    /**
     * 变更履历标题头
     */
    public static final String[] REVISON_HISTORY_TABLE_HEADER = new String[]{"序号", "修订内容及理由","版本", "操作人", "操作时间"};

    /**
     * 用户导入模板
     */
    public static String USER_IMPORT_TABLE_SHEET = "用户导入模板";

    /**
     * 用户导入标题头
     */
    //public static String[] USER_IMPORT_TABLE_HEADER = new String[]{"ID", "*用户名称", "*姓名", "组织\n(多个组织换行隔开)", "部门名称", "权限\n(多个权限换行隔开)", "邮箱", "手机号码", "*工号", "角色\n(多个角色换行隔开)", "用户性别\n(男/女/未知)", "*帐号状态\n(正常/停用)"};
    public static String[] USER_IMPORT_TABLE_HEADER = new String[]{"ID", "*用户名称", "*工号", "*姓名", "邮箱", "*帐号状态\n(正常/停用)", "角色\n(多个角色换行隔开)","领域", "备注"};

    /**
     * 字典数据模板
     */
    public static String[] DICT_DATA_TEMPLATE_HEADER = new String[]{"*字典标签", "*字典键值", "样式属性", "*字典排序", "*回显样式", "备注"};

    /**
     * 用户导入模板
     */
    public static String DICT_DATA_TEMPLATE_SHEET = "字典数据导入模板";

    /**
     * 逆向改进清单导入模版
     */
    public static String VITAL_PROBLEM_TEMPLATE_SHEET = "逆向改进清单导入模版";

    /**
     * 逆向改进清单标题头
     */
    public static String[] VITAL_PROBLEM_TEMPLATE_HEADER = new String[]{"*领域-产品类", "*产品名称", "问题单号", "发生环节", "*故障描述", "*故障原因", "故障影响", "故障类型", "发生场景", "相关领域", "*预防措施", "探测措施", "备注"};

}
