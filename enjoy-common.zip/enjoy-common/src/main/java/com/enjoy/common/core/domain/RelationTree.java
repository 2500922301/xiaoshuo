package com.enjoy.common.core.domain;

import java.io.Serializable;
import java.util.List;

/**
 * 矩阵树 实体
 *
 * @author 86173
 * @date 2021/11/29
 */
public class RelationTree implements Serializable {
    private static final long serialVersionUID = -8136388568849831017L;

    /**
     * 业务ID
     */
    private Long id;

    /**
     * 树ID
     */
    private Long treeId;

    /**
     * 节点类型
     */
    private Integer nodeType;

    /**
     * 是否关联当前节点,true-已关联， false-未关联
     */
    private Boolean nodeBind;

    /**
     * 节点关系
     */
    private Integer nodeRelation;

    /**
     * 节点展示值
     */
    private String label;

    /**
     * 是否有子节点
     */
    private String hasChild;

    /**
     * true-不可勾选， false-可勾选
     */
    private boolean disabled;

    /**
     * X轴
     */
    private Integer nodeXAxis;

    /**
     * Y轴
     */
    private Integer nodeYAxis;

    List<RelationTree> children;

    public RelationTree() {
    }

    public RelationTree(Long treeId,Long id, Integer nodeType, Integer nodeRelation, String label, String hasChild,Boolean nodeBind,Boolean disabled) {
        this.id = id;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.label = label;
        this.hasChild = hasChild;
        this.nodeBind =nodeBind;
        this.disabled =disabled;
        this.treeId=treeId;
    }

    public RelationTree(Long id, Integer nodeType, Integer nodeRelation, String label, String hasChild, Integer nodeXAxis, Integer nodeYAxis) {
        this.id = id;
        this.nodeType = nodeType;
        this.nodeRelation = nodeRelation;
        this.label = label;
        this.hasChild = hasChild;
        this.nodeXAxis = nodeXAxis;
        this.nodeYAxis = nodeYAxis;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getNodeType() {
        return nodeType;
    }

    public void setNodeType(Integer nodeType) {
        this.nodeType = nodeType;
    }

    public Integer getNodeRelation() {
        return nodeRelation;
    }

    public void setNodeRelation(Integer nodeRelation) {
        this.nodeRelation = nodeRelation;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getHasChild() {
        return hasChild;
    }

    public void setHasChild(String hasChild) {
        this.hasChild = hasChild;
    }

    public Integer getNodeXAxis() {
        return nodeXAxis;
    }

    public void setNodeXAxis(Integer nodeXAxis) {
        this.nodeXAxis = nodeXAxis;
    }

    public Integer getNodeYAxis() {
        return nodeYAxis;
    }

    public void setNodeYAxis(Integer nodeYAxis) {
        this.nodeYAxis = nodeYAxis;
    }

    public Boolean getNodeBind() {
        return nodeBind;
    }

    public void setNodeBind(Boolean nodeBind) {
        this.nodeBind = nodeBind;
    }

    public List<RelationTree> getChildren() {
        return children;
    }

    public void setChildren(List<RelationTree> children) {
        this.children = children;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public Long getTreeId() {
        return treeId;
    }

    public void setTreeId(Long treeId) {
        this.treeId = treeId;
    }
}
