package com.enjoy.common.utils.vo;

public class ExeclOptionVo {
    /**
     * 开始行数
     */
    private int firstRow;
    /**
     * 多少行有效
     */
    private  int lastRow;
    /**
     * 第几单元格开始
     */
    private  int firstCol;
    /**
     * 第几单元格结束
     */
    private  int lastCol;
    /**
     * 参数
     */
    private  String[]  optionArr;

    public ExeclOptionVo() {
    }

    public ExeclOptionVo(int firstRow, int lastRow, int firstCol, int lastCol, String[] optionArr) {
        this.firstRow = firstRow;
        this.lastRow = lastRow;
        this.firstCol = firstCol;
        this.lastCol = lastCol;
        this.optionArr = optionArr;
    }

    public int getFirstRow() {
        return firstRow;
    }

    public void setFirstRow(int firstRow) {
        this.firstRow = firstRow;
    }

    public int getLastRow() {
        return lastRow;
    }

    public void setLastRow(int lastRow) {
        this.lastRow = lastRow;
    }

    public int getFirstCol() {
        return firstCol;
    }

    public void setFirstCol(int firstCol) {
        this.firstCol = firstCol;
    }

    public int getLastCol() {
        return lastCol;
    }

    public void setLastCol(int lastCol) {
        this.lastCol = lastCol;
    }

    public String[] getOptionArr() {
        return optionArr;
    }

    public void setOptionArr(String[] optionArr) {
        this.optionArr = optionArr;
    }
}
