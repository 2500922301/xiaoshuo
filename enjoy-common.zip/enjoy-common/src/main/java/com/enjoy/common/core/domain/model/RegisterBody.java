package com.enjoy.common.core.domain.model;

/**
 * 用户注册对象
 *
 * @author enjoy
 */
public class RegisterBody extends LoginBody
{

}
