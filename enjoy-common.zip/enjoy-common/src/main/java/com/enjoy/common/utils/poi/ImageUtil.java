package com.enjoy.common.utils.poi;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

public class ImageUtil {

    /**
     * 创建水印文件
     *
     * @param watermark
     * @return
     */
    public static BufferedImage createWaterMark(String watermark) throws IOException {
        Integer width = 400;
        String[] words = watermark.split("\n");
        Integer height = words.length * 25 + 60;
        // 获取bufferedImage对象
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        java.awt.Font font = null;
        InputStream inputStream = null;
        try {
            ClassPathResource cpr = new ClassPathResource("template/SIMYOU.TTF");
            inputStream = cpr.getInputStream();
            font = Font.createFont(Font.TRUETYPE_FONT, inputStream).deriveFont(18f);
            // 获取Graphics2d对象
            Graphics2D g2d = image.createGraphics();
            image = g2d.getDeviceConfiguration().createCompatibleImage(width, height, Transparency.TRANSLUCENT);
            g2d.dispose();
            g2d = image.createGraphics();
            g2d.setColor(new Color(170, 170, 170, 80));
            //设置字体颜色和透明度
            g2d.setStroke(new BasicStroke(1));
            // 设置字体
            g2d.setFont(font);
            // 设置字体类型  加粗 大小
            g2d.rotate(Math.toRadians(-10), (double) image.getWidth() / 2, (double) image.getHeight() / 2);
            //设置倾斜度
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER));
            // 支持多行
            for (int i = 0; i < words.length; i++) {
                g2d.drawString(words[i], 50, (i + 1) * 25 + 15);
            }
            g2d.dispose();
        } catch (FontFormatException e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return image;
    }
}
